const Product = require('../models/Product');

exports.getAddProduct = (req, res, next) => {
  res.render('admin/add-expenses', {
    pageTitle: 'Add Expenses',
    path: '/admin/add-expenses',
    editing: false
  });
};

exports.postAddProduct = async (req, res, next) => {
  const sellingPrice = req.body.sellingPrice;
  const productName = req.body.productName;
  const category = req.body.category;
  try {
    const data = await Product.create({
      sellingPrice: sellingPrice,
      productName: productName,
      category: category
    });
    res.redirect('/products');
  } catch(error) {
    console.log(error);
    //res.redirect('/404');
  }
};

exports.getEditProduct = (req, res, next) => {
  const editMode = req.query.edit;
  if(!editMode  || editMode !== 'true') {
    return res.redirect('/products');
  }
  const prodId = req.params.productId;
  Product.findByPk(prodId)
    .then(product => {
      if(!product){
        return res.redirect('/products');
      }
      res.render('admin/add-expenses', {
        pageTitle: 'Edit Expenses',
        path: '/admin/edit-expenses',
        editing: editMode,
        product: product
      });
    })
    .catch(err => {
      console.error('Error fetching product:', err);
      res.redirect('/products');
    });
};

exports.postEditProduct = (req, res) => {
  const prodId = req.body.productId;
  const updatedSellingPrice = req.body.sellingPrice;
  const updatedProductName = req.body.productName;
  const updatedCategory = req.body.category;

  Product.findByPk(prodId)
    .then(product => {
      if(!product) {
        return res.redirect('/products');
      }

      product.sellingPrice = updatedSellingPrice;
      product.productName = updatedProductName;
      product.category = updatedCategory;

      return product.save();
    })
    .then(result => {
      res.redirect('/products');
    })
    .catch(err => {
      console.error('Error updating product', err);
      res.redirect('/products');
    });
};

exports.postDeleteProduct = async (req, res) => {
  const productId = req.params.productId;

  try{ 
    await Product.destroy({
      where: { id: productId }
    });
    res.redirect('/products');
  } catch(error) {
    console.log(error);
    res.status(500).send('Internal Server Error');
  }
};


exports.getProducts = (req, res, next) => {
  Product.findAll()
  .then(products => {
    res.render('admin/products', {
      prods: products,
      pageTitle: 'Edit Details',
      path: '/admin/products'
    });
  })
  .catch(err => {
    console.log(err);
  });
};
