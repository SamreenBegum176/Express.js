const path = require('path');

const express = require('express');

const userController = require('../controllers/shop');

const router = express.Router();

router.get('/', userController.getIndex);

router.get('/products', userController.getProducts);




module.exports = router;
