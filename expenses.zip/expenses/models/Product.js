const Sequelize = require('sequelize');

const sequelize = require('../util/database');

const Product = sequelize.define('product', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    allowNull: false,
    primaryKey: true,
  },
  sellingPrice: {
    type: Sequelize.INTEGER
  },
  productName: {
    type: Sequelize.STRING
  },
  category: {
    type: Sequelize.STRING
  }
});

module.exports = Product;