const express = require('express');
const bodyParser = require('body-parser');
const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

const rootDir = require('./util/path');
const adminRoutes = require('./routes/admin');
const sequelize = require('./util/database');
const Blog = require('./models/Blog');
const Comment = require('./models/Comment');


const app = express();




app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(rootDir, 'public')));
app.use(bodyParser.json());




Blog.hasMany(Comment);
Comment.belongsTo(Blog);


app.use(adminRoutes);

sequelize.sync()
  .then(() => console.log('Database & tables created!'))
  .catch(err => console.log('An error occurred: ', err));



app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
