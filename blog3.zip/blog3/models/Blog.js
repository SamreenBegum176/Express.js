const { Sequelize, DataTypes } = require('sequelize');

const sequelize = require('../util/database');

const Blog = sequelize.define('blog', {
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    author: {
        type: DataTypes.STRING,
        allowNull: false
    },
    content: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    },
    {
        timestamps: false
    }
);


module.exports = Blog;