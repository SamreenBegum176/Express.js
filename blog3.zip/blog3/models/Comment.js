const { Sequelize, DataTypes } = require('sequelize');

const sequelize = require('../util/database');

const Comment = sequelize.define('comment', {
    commentText: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    },
    {
        timestamps: false
    }
);

module.exports = Comment;