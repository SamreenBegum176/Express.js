const Sequelize = require('sequelize');

const sequelize = new Sequelize('practice', 'root', 'sam123', {
    host: 'localhost',
    dialect: 'mysql'
  });

  module.exports = sequelize;