const path = require('path');
const Blog = require('../models/Blog');
const Comment = require('../models/Comment');

exports.addBlog = (req, res, next) => {
    const { title, author, content } = req.body;

     Blog.create({ title, author, content })
        .then(blog => {
        console.log('Blog created:', blog);
        //res.send('Blog created successfully!');
        res.sendFile(path.join(__dirname, '../index.html'));
        })
        .catch(err => {
        console.error('Error creating user:', err);
        res.status(500).send('Error creating user');
        });
};

exports.getBlogs = (req, res, next) => {
    Blog.findAll({ include: Comment })
        .then(blogs => {
            res.json(blogs);
        })
        .catch(err => {
            console.error('Error fetching blogs:', err);
            res.status(500).json({ error: 'Error fetching blogs'});
    });
}

exports.addComments = (req, res, next) => {
    const { blogId, commentText } = req.body;

    Comment.create({ commentText, blogId })
        .then(comment => {
            console.log('Comment created', comment);
            res.send('Comment addend successfully!');
        })
        .catch(err => {
            console.error('Error creating comment:', err);
            res.status(500).send('Error creating comment');
        });
}

exports.getComments = (req, res, next) => {
    const blogId = req.params.blogId;

    Comment.findAll({ where: { blogId }})
        .then(comments => {
            res.json(comments);
        })
        .catch(err => {
            console.error('Error fetching comments', err);
            res.status(500).json({ error: 'Error fetching comments' });
        });
}

exports.deleteComments = (req, res, next) => {
    const commentId = req.params.commentId;

    Comment.destroy({ where: { id: commentId }})
    .then(() => {
        console.log('Comment deleted successfully');
        res.send('Comment deleted successfully');
    })
    .catch(err => {
        console.error('Error deleting comment:', err);
        res.status(500).send('Error deleting comment');
    });
};
