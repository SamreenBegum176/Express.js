const express = require('express');

const router = express.Router();

const adminController = require('../controllers/admin');

router.post('/saveBlog', adminController.addBlog);
router.get('/blogs', adminController.getBlogs);
router.post('/saveComment', adminController.addComments);
router.get('/blogs/:blogId/comments', adminController.addComments);
router.delete('/comment/:commentId',adminController.deleteComments);

module.exports = router;