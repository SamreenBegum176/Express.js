const Comment = require('../models/Comment')

exports.saveBlogForm = (req, res, next) => {
    let newTitle = req.body.title;
    let newAuthor = req.body.author;
    let newContent = req.body.content;
    return req.user
        .createBlog({
            title: newTitle,
            author: newAuthor,
            content: newContent
        })
        .then((result) => {
            res.redirect('/createBlog');
        })
        .catch((err) => console.log('error in adding a blog'));
};

exports.saveCommentForm = (req, res, next) => {
    let newCommentText = req.body.commentText;
    let newBlogId = req.body.blogId;

    return req.user 
        .createComment({
            commentText: newCommentText,
            blogId: newBlogId
        })
        .then(() => {
            res.redirect('/createBlog');
        });
};

exports.deleteBlogComment = (req, res, next) => {
    const commentId = req.body.commentId;
    
    Comment.destroy({
        where: {
            id: commentId,
        },
    })
        .then(() => {
            res.redirect('/createBlog');
        })
        .catch((err) =>{
            console.error('Error in deleting comment', err);
            res.status(500).send('Error deleting comment');
        });
};
