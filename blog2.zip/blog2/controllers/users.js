exports.getBlogForm = (req, res, next) => {
    req.user.getBlogs({ include: ["comments"]})
        .then((blogs) => {
          res.render("add-blog", {
            blogs: blogs
        }); 
    });
};
