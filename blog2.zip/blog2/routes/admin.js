const express = require('express');

const router = express.Router();

const adminController = require('../controllers/admin');

router.post('/saveblog', adminController.saveBlogForm);
router.post('/saveComment', adminController.saveCommentForm);
router.post('/deleteComment',adminController.deleteBlogComment);

module.exports = router;