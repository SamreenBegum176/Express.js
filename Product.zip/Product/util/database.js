const Sequelize = require('sequelize');

const sequelize = new Sequelize('samreen', 'root', 'sam123', {
  dialect: 'mysql',
  host: 'localhost'
});

module.exports = sequelize;
